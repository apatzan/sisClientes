@extends ('layouts.admin')
@section ('contenido')

<head>

  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>
</head>


<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-6 col-xs-14">
		<!--
			<a href="{{URL::action('GestionController@create',$cliente->id)}}"><button class="btn btn-info">Nueva Gestión</button></a>
			<a href="{{URL::action('PromesaController@create',$cliente->id)}}"><button class="btn btn-primary">Promesa de Pago</button></a>
			<a href="{{URL::action('RecordatorioController@create',$cliente->id)}}"><button class="btn btn-info">Recordatorio</button></a>
			-->
			@can('isSupervisor')
			<a href="{{url('cliente/general')}}"><button class="btn btn-danger">Regresar</button></a>
			@endcan

			@can('isAdmin')
			<a href="{{url('cliente/general')}}"><button class="btn btn-danger">Regresar</button></a>
			@endcan
			@can('isAgente')
			<a href="{{url('cliente/consulta')}}"><button class="btn btn-danger">Regresar</button></a>
			@endcan
		</div>
	</div>

	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-6 col-xs-14">
			<h3>Detalles de Cliente: {{ $cliente->nombre}}</h3>
		</div>

	</div>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<h4 style="background-color: #e3f2fd">Datos Generales</h4>
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>					
					<th style="width: 150px;">Telefono Casa</th>
					<th style="width: 150px;">Telefono Trabajo</th>
					<th style="width: 150px;">Celular</th>
					<th style="width: 150px;">Cuenta</th>
					<th style="width: 150px;">Moneda</th>
					<th style="width: 150px;">Gestor</th>
					<th style="width: 150px;">Fecha de Corte </th>
					<th style="width: 150px;">Email </th>
				</thead>
	
				<tr>
				@php

				if ($cliente->saldo >0 and $cliente->pagoMinimo >0 and $cliente->saldoD <=0  ){
				$msj = 'Estimado (a) Señor (a) '  . $cliente->nombre . 
							'%0APresente %0A%0A
				Estimado cliente la presente es para darse por notificado que ha sido traslado a nuestra casa de cobranza externa, GLB CONTACT CENTER, S.A. Por el atraso que presenta de Saldo Total Q'
				.$cliente->saldo .' y Pago Mínimo Q'. $cliente->pagoMinimo. 
				 ' en sus pagos con la TARJETA DE CREDITO BANRURAL. Hemos intentado comunicarnos con usted en varias ocasiones. Le agradeceremos que se comunique con nosotros para brindarle soluciones al estado actual de deuda.
				 %0ASirva la presente, como constancia de recordatorio de pago y la finalización de esta etapa, previo a un posible proceso jurídico.

				 %0AEsperamos su respuesta brevemente a los teléfonos PBX 23266810, o al correo electrónico: atp@banrural.com.gt';
				}
				else {
					if ($cliente->saldo >0 and $cliente->pagoMinimo >0 and $cliente->saldoD >0){
					$msj = 'Estimado (a) Señor (a) '  . $cliente->nombre . 
							'%0APresente %0A%0A
				Estimado cliente la presente es para darse por notificado que ha sido traslado a nuestra casa de cobranza externa, GLB CONTACT CENTER, S.A. Por el atraso que presenta de Saldo Total Q'
				.$cliente->saldo .' y Pago Mínimo Q'. $cliente->pagoMinimo. ' Saldo Total $'. $cliente->saldoD.' Pago Minimo $'.$cliente->pagoMinimoD.
				 ' en sus pagos con la TARJETA DE CREDITO BANRURAL. Hemos intentado comunicarnos con usted en varias ocasiones. Le agradeceremos que se comunique con nosotros para brindarle soluciones al estado actual de deuda.'.
				 '%0A%0A Sirva la presente, como constancia de recordatorio de pago y la finalización de esta etapa, previo a un posible proceso jurídico.'.

				 '%0AEsperamos su respuesta brevemente a los teléfonos PBX 23266810, o al correo electrónico: atp@banrural.com.gt';
					}else
					{
						$msj = 'Estimado (a) Señor (a) '  . $cliente->nombre . 
						'%0APresente %0A%0A
						Estimado cliente la presente es para darse por notificado que ha sido traslado a nuestra casa de cobranza externa, GLB CONTACT CENTER, S.A. Por el atraso que presenta de Saldo Total $'
				.$cliente->saldoD .' y Pago Mínimo $'. $cliente->pagoMinimoD. 
				 ' en sus pagos con la TARJETA DE CREDITO BANRURAL. Hemos intentado comunicarnos con usted en varias ocasiones. Le agradeceremos que se comunique con nosotros para brindarle soluciones al estado actual de deuda.'.
				 '%0A%0A Sirva la presente, como constancia de recordatorio de pago y la finalización de esta etapa, previo a un posible proceso jurídico.

				 %0AEsperamos su respuesta brevemente a los teléfonos PBX 23266810, o al correo electrónico: atp@banrural.com.gt';	
					};
				};
				@endphp

					<td>{{ $cliente->telCasa}}</td>
					<td>{{ $cliente->telTrabajo}}</td>
					<td>{{ $cliente->celular}}</td>
					<td>{{ $cliente->cuenta}}</td>
					<td>{{ $cliente->moneda}}</td>
					<td>{{ $cliente->responsable}}</td>
					<td>{{ $cliente->fechaCorte}}</td>
					<td>
					<a href="mailto:{{ $cliente->email}}?Subject=RECORDATORIO DE PAGO BANRURAL &Body={{$msj}} ">
					{{ $cliente->email}}
					</a>
					
		
					</td>
					<!--
					<td><a href="{{ $cliente->email}}">{{ $cliente->email}}</a></td>
					-->
					
				</tr>
			</table>
		</div>

	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-1 col-sm-12 col-xs-12">
	<h4 style="background-color: #e3f2fd">Detalle Quetzales</h4>
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>					
					<th style="width: 150px;">Saldo</th>
					<th style="width: 150px;">Saldo Vencido</th>
					<th style="width: 150px;">Pago Minimo</th>
					<th style="width: 150px;">Monto Ultimo Pago</th>
					<th style="width: 150px;">Fecha Ultimo Pago</th>
					<th style="width: 150px;">Cesantes</th>
					<th style="width: 150px;">CuotasVencidas</th>

					
				</thead>
   
				<tr>
					<td>{{ $cliente->saldo}}</td>
					<td>{{ $cliente->saldoVencido}}</td>
					<td>{{ $cliente->pagoMinimo}}</td>
					<td>{{ $cliente->montoUltPago}}</td>
					<td>{{ $cliente->fechaUltPago}}</td>
					<td>{{ $cliente->cesantes}}</td>
					<td>{{ $cliente->cuotasVencidas}}</td>
					
					
				</tr>
			</table>
		</div>

	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<h4 style="background-color: #e3f2fd">Detalle Dólares</h4>
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>					
					<th style="width: 150px;">Saldo</th>
					<th style="width: 150px;">Saldo Vencido</th>
					<th style="width: 150px;">Pago Minimo</th>
					<th style="width: 150px;">Monto Ultimo Pago</th>
					<th style="width: 150px;">Fecha Ultimo Pago</th>
					<th style="width: 150px;">Cesantes</th>
					<th style="width: 150px;">CuotasVencidas</th>
					
					
					
				</thead>
   
				<tr>
					<td>{{ $cliente->saldoD}}</td>
					<td>{{ $cliente->saldoVencidoD}}</td>
					<td>{{ $cliente->pagoMinimoD}}</td>
					<td>{{ $cliente->montoUltPagoD}}</td>
					<td>{{ $cliente->fechaUltPagoD}}</td>
					<td>{{ $cliente->cesantesD}}</td>
					<td>{{ $cliente->cuotasVencidasD}}</td>
					
				<!--	<td>{{ $cliente->fechaCorte}}</td>-->
					
				</tr>
			</table>
		</div>

	</div>
</div>



<!-- Area de Ingreso de Gestiones --> 
<div class="row">
<div class="col-lg-8 col-md-8 col-sm-6 col-xs-14">
<button class="tablink btn btn-primary" onclick="openPage('Gestiones', this, 'green')" id="defaultOpen">Gestiones</button>
<button class="tablink btn btn-primary" onclick="openPage('NuevaGestion', this, 'green')">Nueva Gestion</button>
<button class="tablink btn btn-primary" onclick="openPage('PromesaPago', this, 'green')">Promesa de Pago</button>
<button class="tablink btn btn-primary" onclick="openPage('Recordatorio', this, 'green')">Recordatorio</button>

<div id="Gestiones" class="tabcontent">
</div>

<div id="NuevaGestion" class="tabcontent">
{!!Form::open(array('url'=>'gestion/alta','method'=>'POST','autocomplete'=>'off'))!!}
            {{Form::token()}}
            <div class="form-group">
               
                <input type="hidden" name="idCliente" class=form-control" value={{$cliente->id}} readonly>
            </div>
            <div class="form-group">
            	<label>Tipificación</label>
            	<select name="idTipif" id="idTipif" class="form-control" data-live-search="true">
                    @foreach($tipificaciones as $tip)
                     <option value="{{$tip->id_tipif}}">{{$tip->descripcion}}</option>
                     @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="Estado">Observación</label>
                <!--<input type="text" name="observacion" class=form-control" placeholder="Ingrese Observación">-->
                <input type="text" id="myInput"style="width: 680px;" class="form-control" name="observacion" placeholder="Ingrese una observación" value="" required>
    
            </div>
            <div class="form-group">
                <button class="btn btn-primary" type="submit">Guardar</button>
                <button class="btn btn-danger" type="reset">Cancelar</button>
            </div>

            {!!Form::close()!!}    
</div>

<div id="PromesaPago" class="tabcontent">
{!!Form::open(array('url'=>'promesa/alta','method'=>'POST','autocomplete'=>'off'))!!}
            {{Form::token()}}

			<div class="form-group">
               
			   <input type="hidden" name="idCliente" class=form-control" value={{$cliente->id}} readonly>
		   </div>

            <div class="form-group">
            	<label>Tipificación</label>
            	<select name="idTipif" id="idTipif" class="form-control" data-live-search="true">
                    @foreach($tipificacionesprom as $tip)
                     <option value="{{$tip->id_tipif}}">{{$tip->descripcion}}</option>
                     @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="Estado">Observación</label>
                <!--<input type="text" name="observacion" class=form-control" placeholder="Ingrese Observación">-->
                <input type="text" id="myInput"style="width: 680px;" class="form-control" name="observacion" placeholder="Ingrese una observación" value="" required>
    
            </div>
            <div class="form-group">
                <label for="Fecha">Fecha Promesa</label>
                <!--<input type="text" name="observacion" class=form-control" placeholder="Ingrese Observación">-->
                <input class="date form-control" type="text" name="fechaPromesa" required>
             </div>
             <script type="text/javascript">

    $('.date').datepicker({  

       format: 'yyyy-mm-dd',
       autoclose: true

     });  
</script>

            <div class="form-group">
                <button class="btn btn-primary" type="submit">Guardar</button>
                <button class="btn btn-danger" type="reset">Cancelar</button>
            </div>

            {!!Form::close()!!}
</div>

<div id="Recordatorio" class="tabcontent">
{!!Form::open(array('url'=>'recordatorio/alta','method'=>'POST','autocomplete'=>'off'))!!}
            {{Form::token()}}
            <div class="form-group">
               
                <input type="hidden" name="idCliente" class=form-control" value={{$cliente->id}} readonly>
            </div>
            <div class="form-group">
            	<label>Tipificación</label>
            	<select name="idTipif" id="idTipif" class="form-control" data-live-search="true">
                    @foreach($tipificacionesrec as $tip)
                     <option value="{{$tip->id_tipif}}">{{$tip->descripcion}}</option>
                     @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="Observacion">Observación</label>
                <!--<input type="text" name="observacion" class=form-control" placeholder="Ingrese Observación">-->
                <input type="text" id="myInput"style="width: 680px;" class="form-control" name="observacion" placeholder="Ingrese una observación" value="" required>
    
            </div>
            <div class="form-group">
                <label for="Fecha">Fecha Recordatorio</label>
                <!--<input type="text" name="observacion" class=form-control" placeholder="Ingrese Observación">-->
                <input class="date form-control" type="text" name="fechaPromesa" required>
             </div>
             <script type="text/javascript">

    $('.date').datepicker({  

       format: 'yyyy-mm-dd',
       autoclose: true

     });  
</script>

<div class="form-group">
                <label for="horaRecordatorio">Hora</label>
                <!--<input type="text" name="observacion" class=form-control" placeholder="Ingrese Observación">-->
                <input type="time" id="myInput"style="width: 680px;" class="form-control" name="horaRecordatorio" required >
    
            </div>


            <div class="form-group">
                <button class="btn btn-primary" type="submit">Guardar</button>
                <button class="btn btn-danger" type="reset">Cancelar</button>
            </div>

            {!!Form::close()!!}   
</div>

<script>
function openPage(pageName, elmnt, color) {
  // Hide all elements with class="tabcontent" by default */
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Remove the background color of all tablinks/buttons
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }

  // Show the specific tab content
  document.getElementById(pageName).style.display = "block";

  // Add the specific color to the button used to open the tab content
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>


<!-- Fin Area de Ingreso de gestiones -->



	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-6 col-xs-14">	
			<h3>Gestiones:</h3>
		</div>

	</div>
	</div>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>					
					<th style="width: 20px;">Id Gestion</th>
					<th style="width: 80px;">Fecha</th>
					<th style="width: 100px;">Descripción</th>
					<th style="width: 65px;">Fecha Promesa/Record</th>
					<th style="width: 35px;">Hora Recordatorio</th>
					<th style="width: 200px;">Observación</th>
					<th style="width: 100px;">Usuario Ingreso</th>
				</thead>
			
			<tbody>
               @foreach($gestion as $ges)                               
				<tr>
					<td>{{ $ges->idGestion}}</td>
					<td>{{ $ges->fecha}}</td>
					<td>{{ $ges->descripcion}}</td>
					<td>{{ $ges->fechaPromesa}}</td>
					<td>{{ $ges->horaRecordatorio}}</td>
					<td>{{ $ges->observacion}}</td>
					<td>{{ $ges->userIngreso}}</td>

				</tr>
				@endforeach
             </tbody>
			</table>
		</div>

	</div>
</div>







@endsection
